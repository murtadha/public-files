# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 12:18:27 2023

@author: kevin
"""

from input_1 import segy_reader
from output import output_segy
from procs import stack_traces,freq_filtering

# %%

shape = True
file = True
trace = True

path = 'example_data/SC_204_PM.segy'

seismic = segy_reader(path,shape=shape,file=file,trace=trace)

dataset = seismic.dataset
sample_interval = seismic.sample_interval


# %%

freq1 = 10 # Frequency in Hz
freq2 = 20 # Frequency in Hz
freq3 = 60 # Frequency in Hz
freq4 = 90 # Frequency in Hz
win1=None
win2=None
notch=False

dataset_filtered = freq_filtering(dataset,freq1=freq1,freq2=freq2,freq3=freq3,freq4=freq4,win1=win1,win2=win2,notch=notch,si=sample_interval)


# %%

dataset_stack = stack_traces(dataset)

# %%

path_output_filtered = '.output/SC_204_PM_filtered.segy'

output_segy(path,dataset_filtered,path_output_filtered)

# %% 

path_output_stack = '.output/SC_204_PM_stack.segy'

output_segy(path,dataset_stack,path_output_stack)
