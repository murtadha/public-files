# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 12:08:01 2023

@author: kevin
"""

from input_1 import segy_reader
import struct

def output_segy(segy_file,dataset,name):
    
    """!
            
    Writes a .segy file. Headers are extracted from an already existing .segy file.
    
    Inputs :
    ----------
    @param segy_file \a string \n
        Original .segy file from which the header are extracted to create the new .segy file.
    @param dataset \a 2D-array \n
        Dataset to write in the .segy file.
    @param name \a string \n
        Path and name of the new .segy file. The extension .segy must be included in the name.

    """
    
    
    Sismique = segy_reader(segy_file)
    
    Binary_File_Header = Sismique.binary_file_header
    Binary_Trace_Header = Sismique.binary_trace_header

    f = open(name, 'w+b') 
    
    f_bin_header = Binary_File_Header['header'][0][0][0:3220]
    
    if dataset.ndim == 1:
        f_bin_header += bytes(struct.pack('>H',dataset.shape[0]))
    else:
        f_bin_header += bytes(struct.pack('>H',dataset.shape[1]))
        
    f_bin_header += Binary_File_Header['header'][0][0][3222:]

    f_bin_header += bytes(struct.pack('b',0))*(3600-len(f_bin_header))
    
    f.write(f_bin_header)
    
    if dataset.ndim == 1:
        
        # a = len(f_bin_header)
        
        f_bin_header = b''
        
        f_bin_header += Binary_Trace_Header[0][0][0:114]
        f_bin_header += bytes(struct.pack('>H',dataset.shape[0]))
        f_bin_header += Binary_Trace_Header[0][0][116:]

        # add_nb = len(f_bin_header)-a
        
        f_bin_header += bytes(struct.pack('b',0))*(240-len(f_bin_header))
        
        f.write(f_bin_header)
        
        f_bin_header2 = b''
        for j in dataset :
            f_bin_header2 += bytes(struct.pack(">f",j))
            
            if len(f_bin_header2) % 1024 ==0:
                f.write(f_bin_header2)
                f_bin_header2 = b''
            
        f.write(f_bin_header2)    
        
        # f_bin_header += f_bin_header2    
        
    else:
    
        for i in range(dataset.shape[0]):
            
            
            try:
        
                # a = len(f_bin_header)
                f_bin_header = b''
                f_bin_header += Binary_Trace_Header[i][0][0:114]
                f_bin_header += bytes(struct.pack('>H',dataset.shape[1]))
                f_bin_header += Binary_Trace_Header[i][0][116:]
                
                # add_nb = len(f_bin_header)-a
                
                f_bin_header += bytes(struct.pack('b',0))*(240-len(f_bin_header))
                f.write(f_bin_header)
                
            except : 
                
                # a = len(f_bin_header)
                f_bin_header = b''
                f_bin_header += Binary_Trace_Header[0][0][0:114]
                f_bin_header += bytes(struct.pack('>H',dataset.shape[1]))
                f_bin_header += Binary_Trace_Header[0][0][116:]
                
                # add_nb = len(f_bin_header)-a
                
                f_bin_header += bytes(struct.pack('b',0))*(240-len(f_bin_header))
                f.write(f_bin_header)
            
            f_bin_header2 = b''
            for j in dataset[i] :
                
                f_bin_header2 += bytes(struct.pack(">f",j))
                
                if len(f_bin_header2) % 1024 ==0:
                    f.write(f_bin_header2)
                    f_bin_header2 = b''
            f.write(f_bin_header2)
                
            # f_bin_header += f_bin_header2    
        
    
    # f.write(f_bin_header)
    f.close()
    