# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 12:14:06 2023

@author: kevin
"""

import numpy as np

def freq_filtering(seismic,freq1,freq2,freq3,freq4,win1=None,win2=None,notch=False,si=0.001):
    
    """!
    
    Filters the input seismic dataset with a Hann-sloped door function.
    
    The frequencies lower than freq1 and higher than freq4 will be filtered out,
    while the frequencies between freq2 and freq3 will be preserved. 
    
    Between [freq1;freq2], and [freq3;freq4], the door tapers are half-Hann windows.
    
    The wider the gaps between [freq1;freq2], and [freq3;freq4], the gentler the tapers.
    
    The "notch" option allows for band-stop filtering.
    
    See https://wiki.seg.org/wiki/Dictionary:Hanning_function for the maths.
    
    /!\\ USES PROCS.HANN_FILTER() /!\\
    
    Inputs :
    ----------
    @param seismic \a array \n
        Seismic dataset.
    @param freq1 \a scalar \n
        First frequency limit of the filter under which every frequency
        is to be filtered out and over which every frequency is to be attenuated (in hertz).
    @param freq2 \a scalar \n
        Second frequency limit of the filter under which every frequency
        is to be attenuated and over which every frequency is to be preserved (in hertz).
    @param freq3 \a scalar \n
        Third frequency limit of the filter under which every frequency
        is to be preserved and over which every frequency is to be attenuated (in hertz).
    @param freq4 \a scalar \n
        Fourth frequency limit of the filter under which every frequency
        is to be attenuated and over which every frequency is to be filtered out (in hertz).
    @param win1 \a scalar (\a optional) \n
        Lower limit of the computation window (in milliseconds) ; default is 0.
    @param win2 \a scalar (\a optional) \n
        Upper limit of the computation window (in milliseconds) ; default is trace length.
    @param notch \a bool (\a optional) \n
        If True, the filter acts as a band-stop, if False as a band-pass; default is band-pass.
    @param si \a scalar (\a optional) \n
        Sampling interval (in seconds) ; default is 0.001.
    
    Returns :
    ----------
    @param filtered_traces \a array \n
        Filtered seismic dataset.
    
    """
    
    index = np.size(seismic.shape)
    
    if win1 is None:
        win1 = 0
    else:
        win1 = int(win1/(1000*si))
    if win2 is None:
        win2 = int(seismic.shape[index-1])
    else:
        win2 = int(win2/(1000*si))+1

    freq_list = np.fft.fftfreq((win2-win1),d=si)
    
    if int(seismic.shape[index-1])%2 == 0:
        hann = np.zeros(int(len(freq_list)/2))
    else:
        hann = np.zeros(int(len(freq_list)/2)+1)
        
    if notch:
        for i in range(len(hann)):
            hann[i] = 1-hann_filter(freq_list[i],freq1,freq2,freq3,freq4,hann=True)
    else:
        for i in range(len(hann)):
            hann[i] = hann_filter(freq_list[i],freq1,freq2,freq3,freq4,hann=True)
    filtered = np.zeros(len(hann),dtype=complex)
    filtered_traces = np.zeros_like(seismic,dtype=complex)
    
    if index == 2:
        for i in range(seismic.shape[0]):
            fft_Seis = np.fft.fft(seismic[i,win1:win2])
            
            if int(seismic.shape[index-1])%2 == 0:
                spectrum = fft_Seis[0:int(len(fft_Seis)/2)]
            else:
                spectrum = fft_Seis[0:int(len(fft_Seis)/2)+1]
            
            freq_list = freq_list[0:len(spectrum)]
            for j in range(len(freq_list)):
                filtered[j] = hann[j]*spectrum[j]
            negpart = np.copy(np.real(filtered[1:])-1j*np.imag(filtered[1:]))
            
            if int(seismic.shape[index-1])%2 == 0:
                negpart_full = np.append(negpart,0)
            else:
                negpart_full = negpart
            negpart_flip = np.flip(negpart_full)
            fullsig = np.append(filtered,negpart_flip)
            filtered_traces[i] = np.real(np.fft.ifft(fullsig))
            
    else:
        fft_Seis = np.fft.fft(seismic[win1:win2])
        if int(seismic.shape[index-1])%2 == 0:
            spectrum = fft_Seis[0:int(len(fft_Seis)/2)]
        else:
            spectrum = fft_Seis[0:int(len(fft_Seis)/2)+1]
        freq_list = freq_list[0:len(spectrum)]
        for j in range(len(freq_list)):
            filtered[j] = hann[j]*spectrum[j]
        
        negpart = np.copy(np.real(filtered[1:])-1j*np.imag(filtered[1:]))
        if int(seismic.shape[index-1])%2 == 0:
            negpart_full = np.append(negpart,0)
        else:
            negpart_full = negpart
        negpart_flip = np.flip(negpart_full)
        fullsig = np.append(filtered,negpart_flip)
        filtered_traces = np.real(np.fft.ifft(fullsig))
    
    return np.real(filtered_traces)




def hann_filter(freq,freq1,freq2,freq3,freq4,hann=True):
        
    """!
    
    Creates a Hann- or Hamming-sloped door function.
    
    The frequencies lower than freq1 and higher than freq4 will be filtered out,
    while the frequencies between freq2 and freq3 will be preserved. 
    
    Between [freq1;freq2], and [freq3;freq4], the door tapers are half-Hann (or half-Hamming) windows.
    
    The wider the gaps between [freq1;freq2], and [freq3;freq4], the gentler the tapers.
    
    Frequencies have to verify freq1<freq2<=freq3<freq4, else the function is invalid,
    else the function will raise an error.
    
    See https://wiki.seg.org/wiki/Dictionary:Hanning_function for the maths.
    
    Inputs :
    ----------
    @param freq \a scalar \n
        Considered frequency (in hertz).
    @param freq1 \a scalar \n
        First frequency limit of the filter under which every frequency
        is to be filtered out and over which every frequency is to be attenuated (in hertz).
    @param freq2 \a scalar \n
        Second frequency limit of the filter under which every frequency
        is to be attenuated and over which every frequency is to be preserved (in hertz).
    @param freq3 \a scalar \n
        Third frequency limit of the filter under which every frequency
        is to be preserved and over which every frequency is to be attenuated (in hertz).
    @param freq4 \a scalar \n
        Fourth frequency limit of the filter under which every frequency
        is to be attenuated and over which every frequency is to be filtered out (in hertz).
    @param hann \a bool \n
        If hann = True, the returned door function follows a Hann (or hanning) window,
        if False it follows a Hamming window ; default is Hann.
    
    Returns :
    ----------
    @param hann \a array \n
        Designed filter.
    
    """
    
    a = 0.5 if hann else 25/46
    
    if freq1<freq2<=freq3<freq4:
            if freq<=freq1:
                filt = 10**-13 if hann else 25/46-(1-25/46)
            elif freq<=freq2:
                filt = 1-(a+(1-a)*np.cos((np.pi*(freq-freq1)/(freq2-freq1)))) if hann else (a+(1-a)*np.cos((np.pi*(freq-2*freq1+freq2)/(freq2-freq1))))
            elif freq<=freq3:
                filt = 1
            elif freq<=freq4:
                filt = 1-(a+(1-a)*np.cos((np.pi*(freq-2*freq3+freq4)/(freq4-freq3)))) if hann else (a+(1-a)*np.cos((np.pi*(freq-freq3)/(freq4-freq3))))
            elif freq>freq4:
                filt = 10**-13 if hann else 25/46-(1-25/46)
    else:
        raise TypeError('Frequencies have to verify freq1<freq2<=freq3<freq4.')
        
    return filt




def stack_traces(dataset):
    
    """!
    
    Performs a simple stack of the input data.
    
    Inputs :
    ----------
    @param dataset \a array \n
        Seismic dataset to be stacked.

    Returns :
    ----------
    @param stack \a array \n
        Stacked seismic.

    """
    
    dataset = np.array(dataset)
    
    stack = np.zeros(dataset.shape[1])
    
    for i in range(dataset.shape[1]):
        for j in range(dataset.shape[0]):
            stack[i] += dataset[j][i]
        stack[i] = stack[i]/dataset.shape[0]
        
    return np.array(stack)




