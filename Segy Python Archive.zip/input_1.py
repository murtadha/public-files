# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 11:51:41 2023

@author: kevin
"""


import numpy as np

class segy_reader:
    def __init__(self,segy_file,shape=False,file=False,trace=False):
        
        """!
        
        Inputs :
        ----------
        @param segy_file \a string \n
            Path of the input .segy file.
        @param shape \a bool (\a optional) \n
            If True, returns the number of traces and samples per trace of the input .segy file ; default is False.
        @param file \a bool (\a optional) \n
            If True, returns the explained header of the input .segy file ; default is False.
        @param trace \a bool (\a optional) \n
            If True, returns the explained header of the first trace of the input .segy file ; default is False.

        Returns :
        ----------
        If shape = True: returns the number of traces and samples per trace of the input .segy file.
        
        If file = True: returns the explained header of the input .segy file.
        
        If trace = True: returns the explained header of the first trace of the input .segy file.
        
        Callable :
        ----------
        Variables :
            .ebcdic \n
            .file_header \n
            .n_samples \n
            .sample_interval \n
            .segy_format \n
            .additionnal_ebcdic_number \n
            .additionnal_ebcdic \n
            .offset_first_trace \n
            .sample_format \n
            .header_and_trace_seismic \n
            .dataset \n
            .binary_file_header \n
            .binary_trace_header \n
            
        Functions :
            binary_all_traces(fname,trace0,n_samples,sample_format) \n
            binary_header_transfer(self,fname,length) \n
            ebcdic_header(fname) \n
            file_header(fname) \n
            file_header_explained() \n
            seismic_header_traces(fname,trace0,n_samples,sample_format) \n
            trace_header_explained(trace_nb)
        
        """
        
        SEGY_TEXTUAL_HEADER_SIZE = 3200     # Byte-length of the textual header 
        SEGY_BINARY_HEADER_SIZE = 400       # Byte-length of the binary file header
        
        
        self.ebcdic = self.ebcdic_header(segy_file,0,SEGY_TEXTUAL_HEADER_SIZE)  # EBCDIC header
        
        self.file_header = self.file_header(segy_file)  # Organised 400-bytes File Header
        
        self.n_samples = int(self.file_header['3221'][0]) 
        self.sample_interval = int(self.file_header['3217'][0])/1000000
        self.segy_format = int(self.file_header['3501'][0])
        self.additionnal_ebcdic_number = int(self.file_header['3505'][0])
        
        SEGY_ADDITIONAL_TEXTUAL_HEADER_SIZE = 3200*self.additionnal_ebcdic_number
        
        if self.additionnal_ebcdic_number > 0:
            self.additionnal_ebcdic = self.ebcdic_header(segy_file,SEGY_BINARY_HEADER_SIZE + SEGY_TEXTUAL_HEADER_SIZE,SEGY_ADDITIONAL_TEXTUAL_HEADER_SIZE)
        else:
            self.additionnal_ebcdic = []
            
        self.offset_first_trace = SEGY_BINARY_HEADER_SIZE + SEGY_TEXTUAL_HEADER_SIZE + SEGY_ADDITIONAL_TEXTUAL_HEADER_SIZE
        
        self.sample_format = '>f'   # '>f' stands for IEEE-754 float32
        
        self.header_and_trace_seismic = self.seismic_header_traces(segy_file, self.offset_first_trace, self.n_samples, self.sample_format)
        
        self.dataset = np.copy(self.header_and_trace_seismic['trace'])
        
        
        # The two next variables are meant to be used by the function output.output_segy 
        
        self.binary_file_header = self.binary_header_transfer(segy_file,self.offset_first_trace)
        
        self.binary_trace_header = self.binary_all_traces(segy_file,self.offset_first_trace,self.n_samples,self.sample_format)
        
        

        if shape:
            print('The input file contains {} traces of {} samples.'.format(self.dataset.shape[0],self.dataset.shape[1]))
            
        if file:
            self.file_header_explained()
            
        if trace:
            self.trace_header_explained(0)
            
            


    def binary_all_traces(self,fname, trace0, n_samples, sample_format):
        """!
            
        Used to extract all the trace headers in binary

        Parameters
        ----------
        @param fname \a string \n
            path leading to the seismic segy file
        @param trace0 \a int \n
            bytes offset of the first trace header of the file
        @param n_samples \a int \n
            number of samples in one seismic trace
        @param sample_format \a string \n
            numpy dtype format of the seismic samples (default would be '>f')

        Returns
        -------
        @param binary_traces_seismic \a np.memmap \n
            numpy array containing, for each traces, the trace header in binary and the full seismic trace
        
        /!\ Used by OUTPUT.OUTPUT_SEGY

        """
       
        
        binary_traces_dtype = np.dtype([
    #        ('header', (bytes, SEGY_TRACE_HEADER_SIZE)),
            ('header', (bytes,240)),     
            ('trace',  (sample_format, n_samples))
            ])
        binary_traces_seismic= np.memmap(fname, dtype=binary_traces_dtype, offset=trace0, mode='r',)
    
        return binary_traces_seismic


    def binary_header_transfer(self,fname,length):
        """!
                
        Returns the binary array containing Textual Header + File Header + Extended Textual Header

        Parameters
        ----------
        @param fname \a string \n
            path leading to the seismic segy file
        @param length \a int \n
            bytes size of the combined Textual Header + File Header + Extended Textual Header

        Returns
        -------
        @param binary_header \a np.memmap \n
            numpy array containing the Textual Header + File Header + Extended Textual Header in binary
        
        /!\ Used by OUTPUT.OUTPUT_SEGY
        
        """
        
        binary_header_dtype = np.dtype([('header', (bytes,length))])    
        binary_header = np.memmap(fname, dtype=binary_header_dtype, offset=0, mode='r', shape=(1,1))
    
        return binary_header


    def ebcdic_header(self,fname,offset,length):
        
        """!
                    
        Returns the input .segy file EBCDIC header.
        
        Inputs :
        ----------
        @param fname \a string \n
            Path of the input .segy file.
        
        Returns :
        ----------
        @param segy_header \a string \n
            EBCDIC header of the input .segy file.
        
        """
        
        
        number_of_lines = int(length/80)
        
        ebcdic_dtype = np.dtype([('header', (bytes,80))])    
        ebcdic_header = np.memmap(fname, dtype=ebcdic_dtype, offset=offset, mode='r', shape=(1,number_of_lines))
        
        EBCDIC = []
        
        for ligne in ebcdic_header[0]:
            EBCDIC.append(ligne[0])
        
        return EBCDIC


    def file_header(self,fname):
        
        """!
                
        Returns the input .segy file header.
        
        Inputs :
        ----------
        @param fname \a string \n
            Path of the input .segy file.
            
        Returns :
        ----------
        @param segy_binheader \a string \n
            Header of the input .segy file.
        
        """
        
        file_header_dtype = np.dtype([('3201','>u4'),('3205','>u4'),('3209','>u4'),('3213','>u2'),('3215','>u2'),('3217','>u2'),
                                         ('3219','>u2'),('3221','>u2'),('3223','>u2'),('3225','>u2'),('3227','>u2'),('3229','>u2'),
                                         ('3231','>u2'),('3233','>u2'),('3235','>u2'),('3237','>u2'),('3239','>u2'),('3241','>u2'),
                                         ('3243','>u2'),('3245','>u2'),('3247','>u2'),('3249','>u2'),('3251','>u2'),('3253','>u2'),
                                         ('3255','>u2'),('3257','>u2'),('3259','>u2'),('3261', ('i1',240)),('3501','>u2'),('3503','>u2'),
                                         ('3505','>u2')])
        
        file_header = np.memmap(fname, dtype=file_header_dtype, offset=3200, mode='r', shape=(1,1))
        
        return file_header


    def file_header_explained(self):
        
        """!
        
        file_header_explained(self):
        
        Returns the explained input .segy file header.
            
        Returns :
        ----------
        @param segy_binheader \a string \n
            Explained header of the input .segy file.
        
        """
        
        self.File_Header_Explained = ""
        compteur = 0
        Attributs = ['Job Number','Line Number','Reel Number','Number of Data per ensemble',
                     'Number of auxiliary traces per ensemble','Sample Interval (micro secondes)',
                     'Sample Interval 2 (micro secondes)','Number of sample per trace','Number of sample per trace for original field',
                     'Data sample format code','Ensemble fold','Trace Sorting Code','Vertical Sum Code',
                     'Sweep freq at start','Sweep freq at end','Sweep length','Sweep type',
                     'Trace Number','Sweep Taper length (ms) at start','Sweep Taper length (ms) at start',
                     'Taper Type','Correlated','Binary Gain Recovery','Amplitude Recovery Method',
                     'Measurement System','Impulse Signal Polarity','Vibrator Polarity Code',
                     'Unassigned','SEGY format','Fixed length flag','Number of additionnal EBCDIC']
        
        for header in self.file_header[0][0]:
            self.File_Header_Explained += "{} : {} \n ".format(Attributs[compteur],header)
            compteur += 1
            
        print(self.File_Header_Explained)


    def seismic_header_traces(self,fname, trace0, n_samples, sample_format):
        header_and_traces_dtype = np.dtype([
        ('01','>u4'),('05','>u4'),('09','>u4'),('13','>u4'),('17','>u4'),('21','>u4'),('25','>u4'),('29','>i2'),
        ('31','>u2'),('33','>u2'),('35','>u2'),('37','>u4'),('41','>i4'),('45','>i4'),('49','>u4'),('53','>u4'),
        ('57','>u4'),('61','>u4'),('65','>u4'),('69','>u2'),('71','>u2'),('73','>u4'),('77','>u4'),('81','>u4'),
        ('85','>u4'),('89','>u2'),('91','>u2'),('93','>u2'),('95','>i2'),('97','>i2'),('99','>u2'),('101','>u2'),
        ('103','>u2'),('105','>u2'),('107','>u2'),('109','>u2'),('111','>u2'),('113','>u2'),('115','>u2'),('117','>u2'),
        ('119','>u2'),('121','>u2'),('123','>u2'),('125','>u2'),('127','>u2'),('129','>u2'),('131','>u2'),('133','>u2'),
        ('135','>u2'),('137','>u2'),('139','>u2'),('141','>u2'),('143','>u2'),('145','>u2'),('147','>u2'),('149','>u2'),
        ('151','>u2'),('153','>u2'),('155','>u2'),('157','>u2'),('159','>u2'),('161','>u2'),('163','>u2'),('165','>u2'),
        ('167','>u2'),('169','>u2'),('171','>u2'),('173','>u2'),('175','>u2'),('177','>u2'),('179','>u2'),('181','>u4'),
        ('185','>u1'),('186','>u1'),('187','>u1'),('188','>u1'),('189','>u4'),('193','>u4'),('197','>u4'),('201','>i2'),
        ('203','>i2'),('205','>i2'),('207','>i2'),('209','>i2'),('211','>u2'),('213','>u1'),('214','>u1'),('215','>u1'),
        ('216','>u1'),('217','>i4'),('221','>u4'),('225','>u1'),('226','>u1'),('227','>u2'),('229','>u2'),('231','>u1'),
        ('232','>u1'),('233','>u8'),('trace',(sample_format, n_samples))])
        
        header_and_trace_seismic = np.memmap(fname, dtype=header_and_traces_dtype, offset=trace0, mode='r',)
        
        return header_and_trace_seismic


    def trace_header_explained(self,trace_nb):
        
        """!
                
        Returns the explained header of the selected trace from the input .segy file.
        
        Inputs :
        ----------
        @param trace_nb \a integer \n
            Number of the trace to be selected.
            
        Returns :
        ----------
        @param Trace_Header_Explained \a string \n
            Explained header of the selected trace from the input .segy file.
        
        """
        
        self.Trace_Header_Explained = ""
        compteur = 0
        Attributs = ['Trace Sequence Nb within Line','Trace Sequence Nb within SegY','Orig Field Record Nb','Trace Nb within orig. field',
                     'Source Line Nb','Ensemble Nb','Trace Number in CDP Ensemble','Trace Id Code','Number of Vert Summed Trace','Number of Horiz. Stacked Trace',
                     'Data Use','Distance from Source Point','Receiver Group Elevation','Surface Elevation at Source','Source Depth below Surface',
                     'Datum Elevation Rcv Group','Datum Elevation at Source','Water depth at Source','Water depth at Group','Scalar applied to elev.',
                     'Scalar applied to coordinate','Source X','Source Y','Group Coord X','Group Coord Y','Coord Units','Weathering Velocity',
                     'Sub-Weathering Velocity','Uphole Time at Source','Uphole Time at Group','Source Static Correction (ms)','Group Static Correction (ms)',
                     'Total Static Applied','Lag Time A (ms)','Lag Time B (ms)','Delay Recording Time','Mute Time Start (ms)','Mute Time End (ms)',
                     'Number of samples in the trace','Sample Interval (microseconds)','Gain Type','Instrument Gain Constant','Initial Gain',
                     'Correlated','Sweep freq at start','Sweep freq at end','Sweep length','Sweep type','Sweep Taper - Start','Sweep Taper - End',
                     'Taper Type','Alias Filter freq','Alias Filter Slope','Notch Filter freq','Notch filter slope','Low-Cut freq','High-Cut freq','Low-Cut Slope',
                     'High-Cut Slope','Year','Day','Hour','Minute','Second','Time Basis Code','Trace Weighing Factor','Geo Group No Roll Switch',
                     'Geo Group No Trace First','Geo Group No Trace Last','Gap Size','Over Travel','Module Serial Number','Channel Number','Record Index',
                     'Trace Data Process Description','Secondary Low Cut Filter','Receiver Line Number','Receiver Station Number','Source Station Number',
                     'Scalar Applied to ShotPoint','Sample skew (microseconds)','Sensor Azimuth Vertical','Sensor Azimuth Inline','Sensor Azimuth Crossline',
                     'Originator ID','Channel Type','Source Type','Edit Type','Sensor Orientation Description','Record Time Offset (ms)','Shot ID','Receiver Point Index',
                     'Source Point Index','Millisecond in Second','Microsecond in Second','Sensor Type','Reserved','First Sample Time (GPS)']
        
        
        
        for header in range(len(self.header_and_trace_seismic[trace_nb])-1):
            self.Trace_Header_Explained += "{} : {} \n ".format(Attributs[compteur],self.header_and_trace_seismic[trace_nb][header])
            compteur += 1
            
        print(self.Trace_Header_Explained)    

